import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = sessionStorage.getItem('access');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        const refreshToken = sessionStorage.getItem('refresh');
        if (refreshToken) {
          const response = await axios.post(`${API_BASE}/token/refresh/`, {
            refresh: refreshToken,
          });
          
          const { access } = response.data;
          sessionStorage.setItem('access', access);
          
          originalRequest.headers.Authorization = `Bearer ${access}`;
          return api(originalRequest);
        }
      } catch {
        sessionStorage.removeItem('access');
        sessionStorage.removeItem('refresh');
        window.location.href = '/login';
      }
    }
    
    return Promise.reject(error);
  }
);

// Token management
export const getToken = () => sessionStorage.getItem('access');
export const getRefreshToken = () => sessionStorage.getItem('refresh');
export const setTokens = (access: string, refresh: string) => {
  sessionStorage.setItem('access', access);
  sessionStorage.setItem('refresh', refresh);
};
export const clearTokens = () => {
  sessionStorage.removeItem('access');
  sessionStorage.removeItem('refresh');
};

// Types
export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
}

export interface LoginResponse {
  access: string;
  refresh: string;
}

export interface User {
  id: number;
  username: string;
  email: string;
  first_name?: string;
  last_name?: string;
}

export interface ProfileUpdateRequest {
  first_name?: string;
  last_name?: string;
  email?: string;
}

export interface ActivityChartData {
  labels: string[];
  data: number[];
}

// Auth API
export const authAPI = {
  register: (data: RegisterRequest) => api.post('/register/', data),
  login: (data: LoginRequest) => api.post('/login/', data),
  logout: () => api.post('/logout/'),
  refresh: (data: { refresh: string }) => api.post('/token/refresh/', data),
};

// Profile API
export const profileAPI = {
  get: () => api.get('/profile/'),
  update: (data: ProfileUpdateRequest) => api.post('/profile-update/', data),
};

// Activity API
export const activityAPI = {
  getChart: () => api.get('/activity-chart/'),
};

// Export the api instance for direct use if needed
export default api; 