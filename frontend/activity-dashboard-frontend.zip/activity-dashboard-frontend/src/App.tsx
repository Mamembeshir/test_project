import React from 'react';
import { AuthProvider } from './contexts/AuthContext';
import { LoginForm } from './components/LoginForm';
import { RegisterForm } from './components/RegisterForm';
import { Profile } from './components/Profile';
import { ActivityChart } from './components/ActivityChart';
import { Navigation } from './components/Navigation';
import { useAuth } from './hooks/useAuth';
import './App.css';

// Simple router component
const Router = () => {
  const { user, loading } = useAuth();
  const path = window.location.pathname;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!user) {
    if (path === '/register') {
      return <RegisterForm />;
    }
    return <LoginForm />;
  }

  return (
    <div>
      <Navigation />
      {path === '/profile' && <Profile />}
      {path === '/activity' && <ActivityChart />}
      {path === '/' && (
        <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="bg-white shadow rounded-lg p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Welcome to Activity Dashboard</h2>
              <p className="text-gray-600 mb-6">
                This is your personal activity dashboard. Use the navigation above to explore different features.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-indigo-50 p-6 rounded-lg">
                  <h3 className="text-lg font-medium text-indigo-900 mb-2">Profile</h3>
                  <p className="text-indigo-700 mb-4">View and edit your profile information.</p>
                  <a
                    href="/profile"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                  >
                    Go to Profile
                  </a>
                </div>
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="text-lg font-medium text-green-900 mb-2">Activity Chart</h3>
                  <p className="text-green-700 mb-4">View your activity data and charts.</p>
                  <a
                    href="/activity"
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                  >
                    View Activity
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router />
    </AuthProvider>
  );
}

export default App;
